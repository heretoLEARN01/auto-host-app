export * from './compiled-types/src/store/useGarageStore2';
export { default } from './compiled-types/src/store/useGarageStore2';